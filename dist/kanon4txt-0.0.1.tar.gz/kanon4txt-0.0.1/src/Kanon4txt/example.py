def add_one(number):
    return number + 1

def run_anonym(arguments):
    """
    The main function. Runs the anonymization.
    """
    from utils import nlp_utils, cluster_utils, utilization_utils, anonym_utils